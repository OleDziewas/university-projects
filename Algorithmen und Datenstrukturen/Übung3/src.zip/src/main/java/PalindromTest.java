public class PalindromTest {

    public static void main(String[] args) {
        palindromeIdentification pal = new palindromeIdentification();
        char[] A = "lagerregal".toCharArray();
        System.out.println(pal.palindromeIdentification(A));
    }
}
