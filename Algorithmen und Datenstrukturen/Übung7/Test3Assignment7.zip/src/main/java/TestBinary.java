import java.util.LinkedList;
//TestDatei
public class TestBinary {
    public static void main(String[] args) {
        BinarySearchTree bin = new BinarySearchTree();
        bin.add(6);
        bin.add(5);
        bin.add(4);
        bin.add(3);
        bin.add(2);

        System.out.println(bin.isBalanced());
        System.out.println(bin.height(bin.root));
        BinarySearchTree nodes = bin.AVLify();
        System.out.println(nodes.height(nodes.root));
        System.out.println(nodes.isBalanced());
        /*
        System.out.println(bin.isBalanced());
        System.out.println(bin.isEmpty());
        System.out.println(bin.getSize());
        System.out.println(bin.containsKey(9));
        System.out.println(bin.containsKey(9));
        System.out.println("hallo");
        System.out.println(bin.BFS());
        System.out.println(bin.PreOrder());
        System.out.println(bin.InOrder());
        System.out.println(bin.PostOrder());
         */
    }
}
